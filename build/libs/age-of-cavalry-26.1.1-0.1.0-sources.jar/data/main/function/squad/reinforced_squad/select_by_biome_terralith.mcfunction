# 炎热群系 - 6
execute if biome ~ ~ ~ terralith:caldera run function main:squad/reinforced_squad/undead_region/nether
execute if biome ~ ~ ~ terralith:basalt_cliffs run function main:squad/reinforced_squad/undead_region/nether
execute if biome ~ ~ ~ terralith:volcanic_peaks run function main:squad/reinforced_squad/undead_region/nether
execute if biome ~ ~ ~ terralith:volcanic_crater run function main:squad/reinforced_squad/undead_region/nether
execute if biome ~ ~ ~ terralith:cave/mantle_caves run function main:squad/reinforced_squad/undead_region/nether
execute if biome ~ ~ ~ terralith:cave/frostfire_caves run function main:squad/reinforced_squad/undead_region/nether


# 冰雪群系 - 10
execute if biome ~ ~ ~ terralith:frozen_cliffs run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:glacial_chasm run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:cold_shrubland run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:wintry_lowlands run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:wintry_forest run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:alpha_islands_winter run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:skylands_winter run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:snowy_cherry_grove run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:snowy_maple_forest run function main:squad/reinforced_squad/undead_region/north
execute if biome ~ ~ ~ terralith:snowy_shield run function main:squad/reinforced_squad/undead_region/north

# 沙漠群系 - 11
execute if biome ~ ~ ~ terralith:desert_canyon run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:desert_oasis run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:desert_spires run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:gravel_desert run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:lush_desert run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:red_oasis run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:ancient_sands run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:savanna_badlands run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:snowy_badlands run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:warm_river run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:sandstone_valley run function main:squad/reinforced_squad/undead_region/desert
execute if biome ~ ~ ~ terralith:bryce_canyon run function main:squad/reinforced_squad/undead_region/desert


# 沼泽群系 - 2
execute if biome ~ ~ ~ terralith:orchid_swamp run function main:squad/reinforced_squad/undead_region/swamp
execute if biome ~ ~ ~ terralith:ice_marsh run function main:squad/reinforced_squad/undead_region/swamp

execute if biome ~ ~ ~ terralith:cave/fungal_caves run function main:squad/reinforced_squad/undead_region/swamp
execute if biome ~ ~ ~ terralith:cave/infested_caves run function main:squad/reinforced_squad/undead_region/swamp
execute if biome ~ ~ ~ terralith:cave/underground_jungle run function main:squad/reinforced_squad/undead_region/swamp
