
execute as @a at @s if score orbital_cannon aoc_config matches 1 if dimension minecraft:overworld if items entity @s weapon.mainhand fishing_rod[enchantments={binding_curse:1},damage=2,rarity=epic] unless score @s fishing_rod_usage matches 0 run function main:orbital_cannon/nuke/trigger_nuke
execute as @a at @s if score orbital_cannon aoc_config matches 1 if dimension minecraft:overworld if items entity @s weapon.offhand fishing_rod[enchantments={binding_curse:1},damage=2,rarity=epic] unless score @s fishing_rod_usage matches 0 run function main:orbital_cannon/nuke/trigger_nuke
execute as @a at @s if score orbital_cannon aoc_config matches 1 if dimension minecraft:overworld if items entity @s weapon.mainhand fishing_rod[enchantments={binding_curse:1},damage=2,rarity=rare] unless score @s fishing_rod_usage matches 0 run function main:orbital_cannon/drilling/trigger_drilling
execute as @a at @s if score orbital_cannon aoc_config matches 1 if dimension minecraft:overworld if items entity @s weapon.offhand fishing_rod[enchantments={binding_curse:1},damage=2,rarity=rare] unless score @s fishing_rod_usage matches 0 run function main:orbital_cannon/drilling/trigger_drilling
execute as @a at @s if score @s fishing_rod_usage matches 1.. run scoreboard players set @s fishing_rod_usage 0
execute as @a at @s if score @s fishing_rod_usage matches 1.. run say 2
say 1