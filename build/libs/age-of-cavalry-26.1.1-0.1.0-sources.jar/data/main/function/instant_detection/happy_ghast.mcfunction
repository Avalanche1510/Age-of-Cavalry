function main:happy_ghast/air_drive
function main:happy_ghast/bombing_time
function main:happy_ghast/floating