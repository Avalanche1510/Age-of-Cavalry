execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/period_detect
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/team_join
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/animals_break_leaves
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/projectile
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/lightsource_detect
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/ride
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/horn
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/defined_entities
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/set_daytime
execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/trigger
execute if entity @n[type=armor_stand,tag=record] run execute if entity @e[type=happy_ghast] as @n[type=armor_stand,tag=record] at @s run function main:instant_detection/happy_ghast
#execute as @e[type=ender_pearl] at @s run data modify entity @s Owner[0] set from entity @n[type=!item,type=!ender_pearl,type=!armor_stand] UUID[0]
#execute as @e[type=ender_pearl] at @s run data modify entity @s Owner[1] set from entity @n[type=!item,type=!ender_pearl,type=!armor_stand] UUID[1]
#execute as @e[type=ender_pearl] at @s run data modify entity @s Owner[2] set from entity @n[type=!item,type=!ender_pearl,type=!armor_stand] UUID[2]
#execute as @e[type=ender_pearl] at @s run data modify entity @s Owner[3] set from entity @n[type=!item,type=!ender_pearl,type=!armor_stand] UUID[3]

execute as @n[type=armor_stand,tag=record] at @s if entity @p[distance=..16] run data merge entity @s {Invisible:0b,CustomNameVisible:1b}
execute as @n[type=armor_stand,tag=record] at @s unless entity @p[distance=..16] run data merge entity @s {Invisible:1b,CustomNameVisible:0b}

bossbar set world_turbulence players @a

execute if entity @n[type=armor_stand,tag=record] run execute as @n[type=armor_stand,tag=record] at @s run function main:musket_addon/bullet_particles



